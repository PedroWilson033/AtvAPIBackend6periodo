const fs = require('fs');
const path = require('path');
const nm = path.join(__dirname, 'node_modules');

const pkgs = ['iconv-lite', 'body-parser', 'raw-body', 'safer-buffer', 'express'];
pkgs.forEach(pkg => {
  const p = path.join(nm, pkg);
  const exists = fs.existsSync(p);
  if (exists) {
    const pkgJson = JSON.parse(fs.readFileSync(path.join(p, 'package.json'), 'utf8'));
    console.log(pkg + '@' + pkgJson.version + ' deps: ' + JSON.stringify(Object.keys(pkgJson.dependencies || {})));
  } else {
    console.log(pkg + ': NAO ENCONTRADO');
  }
});
