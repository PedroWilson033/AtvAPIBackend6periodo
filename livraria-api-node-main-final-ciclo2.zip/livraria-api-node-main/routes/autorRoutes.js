const express = require('express');
const router = express.Router();
const AutorController = require('../controllers/AutorController');
const { autenticarToken, autorizarRoles } = require('../middlewares/authMiddleware');

/**
 * @openapi
 * /api/v1/autores:
 *   get:
 *     tags:
 *       - Autores
 *     summary: Listar todos os autores
 *     description: |
 *       Retorna a lista completa de autores cadastrados no sistema.
 *
 *       **Acesso:** Público — não requer autenticação.
 *     responses:
 *       '200':
 *         description: Lista de autores retornada com sucesso.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Autor'
 *             example:
 *               - id: 1
 *                 nome: "Machado de Assis"
 *               - id: 2
 *                 nome: "Clarice Lispector"
 *       '500':
 *         description: Erro interno do servidor.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro500'
 *             example:
 *               erro: "Erro interno do servidor."
 */
router.get('/', AutorController.listar);

/**
 * @openapi
 * /api/v1/autores/{id}:
 *   get:
 *     tags:
 *       - Autores
 *     summary: Buscar autor por ID
 *     description: |
 *       Retorna os dados de um autor específico pelo seu ID.
 *
 *       **Acesso:** Público — não requer autenticação.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *           example: 1
 *         description: ID numérico do autor a ser buscado.
 *     responses:
 *       '200':
 *         description: Autor encontrado e retornado com sucesso.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Autor'
 *             example:
 *               id: 1
 *               nome: "Machado de Assis"
 *       '404':
 *         description: Autor com o ID informado não foi encontrado.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro404'
 *             example:
 *               erro: "Autor não encontrado."
 */
router.get('/:id', AutorController.buscarPorId);

/**
 * @openapi
 * /api/v1/autores:
 *   post:
 *     tags:
 *       - Autores
 *     summary: Cadastrar novo autor (ADMIN)
 *     description: |
 *       Cadastra um novo autor no sistema.
 *
 *       **Acesso:** Exclusivo para usuários com perfil **ADMIN**.
 *       Requer token JWT válido no cabeçalho `Authorization: Bearer <token>`.
 *
 *       > 🔐 Autentique-se com `admin@livraria.com` / `admin123` para testar esta rota.
 *     security:
 *       - BearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/AutorInput'
 *           examples:
 *             novo_autor:
 *               summary: Cadastrar novo autor
 *               value:
 *                 nome: "Guimarães Rosa"
 *             outro_autor:
 *               summary: Outro autor brasileiro
 *               value:
 *                 nome: "Jorge Amado"
 *     responses:
 *       '201':
 *         description: Autor cadastrado com sucesso.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Autor'
 *             example:
 *               id: 3
 *               nome: "Guimarães Rosa"
 *       '400':
 *         description: Campo `nome` não informado ou inválido.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro400'
 *             example:
 *               erro: "O nome do autor é obrigatório."
 *       '401':
 *         description: Token JWT ausente, expirado ou inválido.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro401'
 *             example:
 *               erro: "Token não fornecido. Acesso negado."
 *       '403':
 *         description: Usuário autenticado, mas sem permissão de ADMIN.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro403'
 *             example:
 *               erro: "Acesso negado: permissão insuficiente."
 *       '422':
 *         description: Dados inválidos — nome vazio ou formato incorreto.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro422'
 *             example:
 *               erro: "Dados inválidos ou incompletos."
 */
router.post('/', autenticarToken, autorizarRoles('ADMIN'), AutorController.cadastrar);

module.exports = router;