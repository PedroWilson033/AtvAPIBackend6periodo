const express = require('express');
const router = express.Router();
const LivroController = require('../controllers/LivroController');
const { autenticarToken, autorizarRoles } = require('../middlewares/authMiddleware');

/**
 * @openapi
 * /api/v1/livros:
 *   get:
 *     tags:
 *       - Livros
 *     summary: Listar todos os livros
 *     description: |
 *       Retorna o catálogo completo de livros cadastrados na livraria,
 *       incluindo o nome do autor e a lista de comentários de cada livro.
 *
 *       **Acesso:** Público — não requer autenticação.
 *     responses:
 *       '200':
 *         description: Lista de livros retornada com sucesso.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Livro'
 *             example:
 *               - id: 1
 *                 titulo: "Dom Casmurro"
 *                 ano: 1899
 *                 autor_id: 1
 *                 autor_nome: "Machado de Assis"
 *                 comentarios: []
 *               - id: 2
 *                 titulo: "Quincas Borba"
 *                 ano: 1891
 *                 autor_id: 1
 *                 autor_nome: "Machado de Assis"
 *                 comentarios:
 *                   - autor_comentario: "leitor@gmail.com"
 *                     texto: "Livro fantástico!"
 *       '500':
 *         description: Erro interno do servidor.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro500'
 *             example:
 *               erro: "Erro interno do servidor."
 */
router.get('/', LivroController.listar);

/**
 * @openapi
 * /api/v1/livros/{id}:
 *   get:
 *     tags:
 *       - Livros
 *     summary: Buscar livro por ID
 *     description: |
 *       Retorna os dados detalhados de um livro específico pelo seu ID,
 *       incluindo o nome do autor e todos os comentários associados.
 *
 *       **Acesso:** Público — não requer autenticação.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *           example: 1
 *         description: ID numérico do livro a ser buscado.
 *     responses:
 *       '200':
 *         description: Livro encontrado e retornado com sucesso.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Livro'
 *             example:
 *               id: 1
 *               titulo: "Dom Casmurro"
 *               ano: 1899
 *               autor_id: 1
 *               autor_nome: "Machado de Assis"
 *               comentarios:
 *                 - autor_comentario: "leitor@gmail.com"
 *                   texto: "Um clássico da literatura brasileira!"
 *       '404':
 *         description: Livro com o ID informado não foi encontrado.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro404'
 *             example:
 *               erro: "Livro não localizado."
 */
router.get('/:id', LivroController.buscarPorId);

/**
 * @openapi
 * /api/v1/livros:
 *   post:
 *     tags:
 *       - Livros
 *     summary: Cadastrar novo livro (ADMIN)
 *     description: |
 *       Cadastra um novo livro no sistema associado a um autor existente.
 *
 *       **Acesso:** Exclusivo para usuários com perfil **ADMIN**.
 *       Requer token JWT válido no cabeçalho `Authorization: Bearer <token>`.
 *
 *       > 🔐 Autentique-se com `admin@livraria.com` / `admin123` para testar esta rota.
 *     security:
 *       - BearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LivroInput'
 *           examples:
 *             novo_livro:
 *               summary: Cadastrar "Memórias Póstumas de Brás Cubas"
 *               value:
 *                 titulo: "Memórias Póstumas de Brás Cubas"
 *                 ano: 1881
 *                 autor_id: 1
 *             outro_livro:
 *               summary: Cadastrar "A Hora da Estrela"
 *               value:
 *                 titulo: "A Hora da Estrela"
 *                 ano: 1977
 *                 autor_id: 2
 *     responses:
 *       '201':
 *         description: Livro cadastrado com sucesso.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Livro'
 *             example:
 *               id: 3
 *               titulo: "Memórias Póstumas de Brás Cubas"
 *               ano: 1881
 *               autor_id: 1
 *               comentarios: []
 *       '400':
 *         description: Campos obrigatórios não informados (`titulo` ou `autor_id` ausentes).
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro400'
 *             example:
 *               erro: "O título e o autor_id são obrigatórios."
 *       '401':
 *         description: Token JWT ausente, expirado ou inválido.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro401'
 *             example:
 *               erro: "Token não fornecido. Acesso negado."
 *       '403':
 *         description: Usuário autenticado, mas sem permissão de ADMIN.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro403'
 *             example:
 *               erro: "Acesso negado: permissão insuficiente."
 *       '422':
 *         description: Dados inválidos — autor_id não existe no sistema.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro422'
 *             example:
 *               erro: "O autor informado não existe."
 */
router.post('/', autenticarToken, autorizarRoles('ADMIN'), LivroController.cadastrar);

/**
 * @openapi
 * /api/v1/livros/{id}/comentarios:
 *   post:
 *     tags:
 *       - Livros
 *     summary: Adicionar comentário a um livro (USER ou ADMIN)
 *     description: |
 *       Adiciona um comentário a um livro específico.
 *       O e-mail do autor do comentário é extraído automaticamente do token JWT.
 *
 *       **Acesso:** Usuários autenticados com perfil **USER** ou **ADMIN**.
 *       Requer token JWT válido no cabeçalho `Authorization: Bearer <token>`.
 *
 *       > 🔐 Autentique-se com `leitor@gmail.com` / `leitor123` ou com o admin para testar esta rota.
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *           example: 1
 *         description: ID do livro que receberá o comentário.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ComentarioInput'
 *           example:
 *             texto: "Uma obra-prima da literatura brasileira! Leitura obrigatória."
 *     responses:
 *       '201':
 *         description: Comentário adicionado com sucesso.
 *         content:
 *           application/json:
 *             schema:
 *               type: boolean
 *             example: true
 *       '400':
 *         description: O campo `texto` está vazio ou ausente.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro400'
 *             example:
 *               erro: "O texto do comentário não pode estar vazio."
 *       '401':
 *         description: Token JWT ausente, expirado ou inválido.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro401'
 *             example:
 *               erro: "Token não fornecido. Acesso negado."
 *       '404':
 *         description: Livro com o ID informado não encontrado.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro404'
 *             example:
 *               erro: "Livro não localizado."
 *       '422':
 *         description: Dados inválidos — texto não pode ser somente espaços.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro422'
 *             example:
 *               erro: "O texto do comentário não pode estar vazio."
 */
router.post('/:id/comentarios', autenticarToken, autorizarRoles('USER', 'ADMIN'), LivroController.adicionarComentario);

module.exports = router;