const express = require('express');
const router = express.Router();
const AuthController = require('../controllers/AuthController');

/**
 * @openapi
 * /api/v1/auth/register:
 *   post:
 *     tags:
 *       - Autenticação
 *     summary: Cadastrar novo usuário
 *     description: |
 *       Registra um novo usuário no sistema com e-mail único.
 *       Por padrão, o perfil atribuído é **USER**.
 *       Para criar um **ADMIN**, inclua `"role": "ADMIN"` no corpo.
 *
 *       > ⚠️ A senha é armazenada de forma segura com **BCrypt** (salt=10).
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RegisterInput'
 *           examples:
 *             usuario_comum:
 *               summary: Cadastro de usuário padrão (USER)
 *               value:
 *                 nome: "João Silva"
 *                 email: "joao.silva@email.com"
 *                 senha: "minhasenha123"
 *             administrador:
 *               summary: Cadastro de administrador (ADMIN)
 *               value:
 *                 nome: "Maria Admin"
 *                 email: "maria.admin@livraria.com"
 *                 senha: "senhaforte456"
 *                 role: "ADMIN"
 *     responses:
 *       '201':
 *         description: Usuário criado com sucesso. A senha NÃO é retornada.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/RegisterResponse'
 *             example:
 *               id: 3
 *               nome: "João Silva"
 *               email: "joao.silva@email.com"
 *               role: "USER"
 *       '400':
 *         description: Requisição inválida.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro400'
 *             example:
 *               erro: "Requisição inválida."
 *       '409':
 *         description: E-mail já cadastrado no sistema.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro409'
 *             example:
 *               erro: "E-mail já cadastrado."
 *       '422':
 *         description: Campos obrigatórios ausentes ou inválidos (nome, email ou senha com formato inválido).
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro422'
 *             example:
 *               erro: "Campos obrigatórios não informados."
 */
router.post('/register', AuthController.register);

/**
 * @openapi
 * /api/v1/auth/login:
 *   post:
 *     tags:
 *       - Autenticação
 *     summary: Autenticar usuário e obter token JWT
 *     description: |
 *       Autentica o usuário com e-mail e senha e retorna um **token JWT** válido por **8 horas**.
 *
 *       ### Como usar o token
 *       Após obter o token, clique em **Authorize 🔒** no topo desta página e insira:
 *       ```
 *       Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
 *       ```
 *
 *       ### Credenciais de teste pré-cadastradas
 *       | E-mail | Senha | Perfil |
 *       |--------|-------|--------|
 *       | admin@livraria.com | admin123 | ADMIN |
 *       | leitor@gmail.com | leitor123 | USER |
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LoginInput'
 *           examples:
 *             login_admin:
 *               summary: Login como Administrador
 *               value:
 *                 email: "admin@livraria.com"
 *                 senha: "admin123"
 *             login_user:
 *               summary: Login como Usuário comum
 *               value:
 *                 email: "leitor@gmail.com"
 *                 senha: "leitor123"
 *     responses:
 *       '200':
 *         description: Login realizado com sucesso. Copie o `token` para usar nas rotas protegidas.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/LoginResponse'
 *             example:
 *               token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiZW1haWwiOiJhZG1pbkBsaXZyYXJpYS5jb20iLCJyb2xlIjoiQURNSU4iLCJpYXQiOjE3MDAwMDAwMDAsImV4cCI6MTcwMDAyODgwMH0.example"
 *               usuario:
 *                 id: 1
 *                 nome: "Admin"
 *                 email: "admin@livraria.com"
 *                 role: "ADMIN"
 *       '400':
 *         description: Campos email ou senha não fornecidos.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro400'
 *             example:
 *               erro: "Email e senha são obrigatórios."
 *       '401':
 *         description: Credenciais inválidas — e-mail não encontrado ou senha incorreta.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro401'
 *             example:
 *               erro: "Credenciais inválidas."
 *       '422':
 *         description: Dados inválidos ou mal-formatados.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro422'
 *             example:
 *               erro: "Formato de email inválido."
 */
router.post('/login', AuthController.login);

module.exports = router;