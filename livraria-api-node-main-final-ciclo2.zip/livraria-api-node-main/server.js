const express = require('express');
const cors = require('cors');
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./swagger');

const authRoutes = require('./routes/authRoutes');
const livroRoutes = require('./routes/livroRoutes');
const autorRoutes = require('./routes/autorRoutes');
const errorHandler = require('./middlewares/errorMiddleware');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// ─── Documentação OpenAPI / Swagger UI ─────────────────────────────────────
// Interface interativa: GET /docs
// Especificação JSON bruta: GET /docs/api.json
const swaggerUiOptions = {
  customCss: `
    .swagger-ui .topbar { background-color: #1a1a2e; }
    .swagger-ui .topbar-wrapper img { content: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>'); width: 30px; }
    .swagger-ui .info .title { color: #4fc3f7; }
    .swagger-ui .scheme-container { background: #0d1117; padding: 15px; border-radius: 8px; }
  `,
  customSiteTitle: 'Livraria API — Documentação',
  swaggerOptions: {
    persistAuthorization: true,
    displayRequestDuration: true,
    filter: true,
    tryItOutEnabled: true
  }
};

app.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec, swaggerUiOptions));

// Especificação OpenAPI em formato JSON bruto
app.get('/docs/api.json', (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.send(swaggerSpec);
});

// ─── Agrupamento Semântico de Rotas (RESTful /api/v1) ───────────────────────
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/livros', livroRoutes);
app.use('/api/v1/autores', autorRoutes);

// ─── Middleware Global de Tratamento de Erros ───────────────────────────────
app.use(errorHandler);

app.listen(PORT, () => {
  console.log('');
  console.log('╔══════════════════════════════════════════════════════╗');
  console.log('║          Livraria API — Servidor Iniciado            ║');
  console.log('╠══════════════════════════════════════════════════════╣');
  console.log('║  API Base:    http://localhost:' + PORT + '/api/v1            ║');
  console.log('║  Swagger UI:  http://localhost:' + PORT + '/docs              ║');
  console.log('║  OpenAPI JSON: http://localhost:' + PORT + '/docs/api.json    ║');
  console.log('╠══════════════════════════════════════════════════════╣');
  console.log('║  Credenciais de Teste:                               ║');
  console.log('║  ADMIN: admin@livraria.com / admin123                ║');
  console.log('║  USER:  leitor@gmail.com   / leitor123               ║');
  console.log('╚══════════════════════════════════════════════════════╝');
  console.log('');
});