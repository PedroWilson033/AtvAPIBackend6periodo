/**
 * Extrator TAR manual para instalar pacotes npm sem npm.
 * Execute com: agy-node extract-pkg.js <tgz> <destDir> <pkgName>
 */
const zlib = require('zlib');
const fs = require('fs');
const path = require('path');

const tgzPath = process.argv[2];
const destDir = process.argv[3];
const pkgName = process.argv[4];

if (!tgzPath || !destDir || !pkgName) {
  console.error('Uso: agy-node extract-pkg.js <tgz> <destDir> <pkgName>');
  process.exit(1);
}

const pkgDir = path.join(destDir, pkgName);
if (!fs.existsSync(pkgDir)) fs.mkdirSync(pkgDir, { recursive: true });

// Decomprime .tgz
const compressed = fs.readFileSync(tgzPath);
const decompressed = zlib.gunzipSync(compressed);

// Parse TAR manual
let offset = 0;
const buf = decompressed;

function readStr(b, start, len) {
  let end = start;
  while (end < start + len && b[end] !== 0) end++;
  return b.slice(start, end).toString('utf8');
}

while (offset + 512 <= buf.length) {
  const header = buf.slice(offset, offset + 512);
  const rawName = readStr(header, 0, 100);
  if (!rawName) break;
  
  const sizeOctal = readStr(header, 124, 12);
  const size = parseInt(sizeOctal.trim(), 8) || 0;
  const typeflag = String.fromCharCode(header[156]);
  
  offset += 512;
  
  if (typeflag === '0' || typeflag === '' || typeflag === '\0') {
    // Remove prefixo 'package/'
    let cleanName = rawName;
    if (cleanName.startsWith('package/')) {
      cleanName = cleanName.substring('package/'.length);
    }
    
    const outPath = path.join(pkgDir, cleanName);
    const outDir = path.dirname(outPath);
    if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
    fs.writeFileSync(outPath, buf.slice(offset, offset + size));
  }
  
  const blocks = Math.ceil(size / 512);
  offset += blocks * 512;
}

console.log('Extraido:', pkgDir);
