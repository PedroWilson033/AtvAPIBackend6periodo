/**
 * Instala yaml@1.10.2 especificamente dentro do node_modules do swagger-jsdoc
 * para compatibilidade (swagger-jsdoc@6.x usa API da yaml@1.x)
 * Execute: agy-node fix-yaml-compat.js
 */
const https = require('https');
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const NODE_MODULES = path.join(__dirname, 'node_modules');
const EXTRACT_SCRIPT = path.join(__dirname, 'extract-pkg.js');
const NODE_EXE = process.execPath;

function downloadFile(url, destPath) {
  return new Promise((resolve, reject) => {
    function doRequest(currentUrl) {
      https.get(currentUrl, (res) => {
        if ([301, 302, 307, 308].includes(res.statusCode)) {
          doRequest(res.headers.location);
          return;
        }
        if (res.statusCode !== 200) {
          reject(new Error('HTTP ' + res.statusCode + ' for ' + currentUrl));
          return;
        }
        const file = fs.createWriteStream(destPath);
        res.pipe(file);
        file.on('finish', () => { file.close(); resolve(); });
        file.on('error', reject);
        res.on('error', reject);
      }).on('error', reject);
    }
    doRequest(url);
  });
}

async function main() {
  // URL direta para yaml@1.10.2
  const tarballUrl = 'https://registry.npmjs.org/yaml/-/yaml-1.10.2.tgz';
  
  console.log('[INFO] Instalando yaml@1.10.2 para swagger-jsdoc...');
  
  // Instala no node_modules do swagger-jsdoc (override local)
  const swaggerJsdocNodeModules = path.join(NODE_MODULES, 'swagger-jsdoc', 'node_modules');
  if (!fs.existsSync(swaggerJsdocNodeModules)) {
    fs.mkdirSync(swaggerJsdocNodeModules, { recursive: true });
  }
  
  // Verifica se ja esta instalado
  const yamlLocalPath = path.join(swaggerJsdocNodeModules, 'yaml');
  if (fs.existsSync(yamlLocalPath)) {
    console.log('[OK] yaml@1.x ja instalado em swagger-jsdoc/node_modules');
  } else {
    const tmpTgz = path.join(NODE_MODULES, '_tmp_yaml1.tgz');
    console.log('[DOWNLOAD] yaml@1.10.2...');
    await downloadFile(tarballUrl, tmpTgz);
    console.log('[EXTRACT] Extraindo yaml@1.10.2...');
    execFileSync(NODE_EXE, [EXTRACT_SCRIPT, tmpTgz, swaggerJsdocNodeModules, 'yaml'], {
      stdio: 'inherit'
    });
    if (fs.existsSync(tmpTgz)) fs.unlinkSync(tmpTgz);
    console.log('[OK] yaml@1.10.2 instalado em swagger-jsdoc/node_modules/yaml');
  }
  
  // Testa o carregamento do swagger.js
  console.log('\n[TESTE] Carregando swagger.js...');
  try {
    execFileSync(NODE_EXE, ['-e', "require('./swagger'); console.log('swagger.js carregado com sucesso!');"], {
      cwd: __dirname,
      stdio: 'inherit'
    });
  } catch (e) {
    console.error('[ERRO]', e.message);
    process.exit(1);
  }
  
  console.log('\n[OK] Compatibilidade corrigida! Inicie o servidor com:');
  console.log('   agy-node server.js');
}

main().catch(err => {
  console.error('[ERRO FATAL]', err.message);
  process.exit(1);
});
