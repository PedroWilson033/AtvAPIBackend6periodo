# Livraria API — OpenAPI 3.0 + Swagger UI

Projeto da atividade de documentação da API de Livros e Autores.

## Instalação

No terminal, dentro desta pasta:

```bash
npm install
npm start
```

Servidor:

- API: http://localhost:3000/api/v1
- Swagger UI: http://localhost:3000/docs
- OpenAPI JSON: http://localhost:3000/docs/api.json

## Teste da autenticação

Usuários pré-cadastrados:

- ADMIN: `admin@livraria.com` / `admin123`
- USER: `leitor@gmail.com` / `leitor123`

No Swagger:

1. Abra `POST /api/v1/auth/login`.
2. Faça login.
3. Copie somente o valor do campo `token`.
4. Clique em `Authorize`.
5. Cole o token no campo Bearer.
6. Clique em `Authorize`.
7. Agora teste as rotas protegidas.

O Swagger envia automaticamente `Authorization: Bearer <token>`.

## Rotas documentadas

- GET `/api/v1/livros` — público
- GET `/api/v1/livros/{id}` — público
- POST `/api/v1/auth/register` — público
- POST `/api/v1/auth/login` — público
- POST `/api/v1/livros/{id}/comentarios` — USER ou ADMIN
- POST `/api/v1/autores` — ADMIN
- POST `/api/v1/livros` — ADMIN

A documentação informa request bodies, campos obrigatórios, exemplos, respostas de sucesso e erros, além do esquema HTTP Bearer/JWT.

## Observação

A pasta `node_modules` não é necessária para o GitHub. Execute `npm install` depois de clonar/baixar o projeto.
