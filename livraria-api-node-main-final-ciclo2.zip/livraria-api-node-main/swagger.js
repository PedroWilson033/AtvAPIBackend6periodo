const swaggerJsdoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.3',
    info: {
      title: 'Livraria API',
      version: '1.0.0',
      description: `
## API de Gerenciamento de Livros e Autores

API RESTful com autenticação JWT e controle de acesso baseado em perfis (RBAC).

### Perfis de Acesso
| Perfil | Descrição |
|--------|-----------|
| **Público** | Sem autenticação. Acesso de leitura aos recursos. |
| **USER** | Usuário autenticado. Pode adicionar comentários em livros. |
| **ADMIN** | Administrador. Pode cadastrar autores e livros. |

### Como Autenticar
1. Realize o login em **POST /api/v1/auth/login**
2. Copie o \`token\` retornado no campo \`token\` da resposta
3. Clique no botão **Authorize 🔒** acima e cole o token no campo **Value** no formato: \`Bearer <seu_token>\`
4. Clique em **Authorize** e feche o modal

### Credenciais de Teste
| E-mail | Senha | Perfil |
|--------|-------|--------|
| admin@livraria.com | admin123 | ADMIN |
| leitor@gmail.com | leitor123 | USER |
      `,
      contact: {
        name: 'Suporte Livraria API',
        email: 'suporte@livraria.com'
      },
      license: {
        name: 'ISC'
      }
    },
    servers: [
      {
        url: 'http://localhost:3000',
        description: 'Servidor de Desenvolvimento Local'
      }
    ],
    components: {
      securitySchemes: {
        BearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
          description: 'Informe apenas o token JWT obtido no endpoint de login. A interface Swagger enviará automaticamente o cabeçalho Authorization: Bearer <token>.'
        }
      },
      schemas: {
        // ─── Auth Schemas ────────────────────────────────────────────────
        RegisterInput: {
          type: 'object',
          required: ['nome', 'email', 'senha'],
          properties: {
            nome: {
              type: 'string',
              example: 'João Silva',
              description: 'Nome completo do usuário'
            },
            email: {
              type: 'string',
              format: 'email',
              example: 'joao.silva@email.com',
              description: 'E-mail único do usuário (usado para login)'
            },
            senha: {
              type: 'string',
              format: 'password',
              minLength: 6,
              example: 'minhasenha123',
              description: 'Senha com no mínimo 6 caracteres'
            },
            role: {
              type: 'string',
              enum: ['USER', 'ADMIN'],
              default: 'USER',
              example: 'USER',
              description: 'Perfil de acesso do usuário (padrão: USER)'
            }
          }
        },
        RegisterResponse: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 3 },
            nome: { type: 'string', example: 'João Silva' },
            email: { type: 'string', format: 'email', example: 'joao.silva@email.com' },
            role: { type: 'string', example: 'USER' }
          }
        },
        LoginInput: {
          type: 'object',
          required: ['email', 'senha'],
          properties: {
            email: {
              type: 'string',
              format: 'email',
              example: 'admin@livraria.com',
              description: 'E-mail cadastrado'
            },
            senha: {
              type: 'string',
              format: 'password',
              example: 'admin123',
              description: 'Senha do usuário'
            }
          }
        },
        LoginResponse: {
          type: 'object',
          properties: {
            token: {
              type: 'string',
              example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
              description: 'Token JWT válido por 8 horas. Use como: Bearer <token>'
            },
            usuario: {
              type: 'object',
              properties: {
                id: { type: 'integer', example: 1 },
                nome: { type: 'string', example: 'Admin' },
                email: { type: 'string', example: 'admin@livraria.com' },
                role: { type: 'string', example: 'ADMIN' }
              }
            }
          }
        },

        // ─── Livro Schemas ───────────────────────────────────────────────
        Livro: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            titulo: { type: 'string', example: 'Dom Casmurro' },
            ano: { type: 'integer', example: 1899 },
            autor_id: { type: 'integer', example: 1 },
            autor_nome: { type: 'string', example: 'Machado de Assis' },
            comentarios: {
              type: 'array',
              items: { $ref: '#/components/schemas/Comentario' }
            }
          }
        },
        LivroInput: {
          type: 'object',
          required: ['titulo', 'autor_id'],
          properties: {
            titulo: {
              type: 'string',
              example: 'Memórias Póstumas de Brás Cubas',
              description: 'Título do livro (obrigatório)'
            },
            ano: {
              type: 'integer',
              example: 1881,
              description: 'Ano de publicação (opcional, padrão: ano atual)'
            },
            autor_id: {
              type: 'integer',
              example: 1,
              description: 'ID do autor já cadastrado (obrigatório)'
            }
          }
        },

        // ─── Comentario Schemas ──────────────────────────────────────────
        Comentario: {
          type: 'object',
          properties: {
            autor_comentario: { type: 'string', example: 'admin@livraria.com' },
            texto: { type: 'string', example: 'Obra-prima da literatura brasileira!' }
          }
        },
        ComentarioInput: {
          type: 'object',
          required: ['texto'],
          properties: {
            texto: {
              type: 'string',
              example: 'Uma leitura obrigatória para qualquer amante da literatura.',
              description: 'Texto do comentário (não pode ser vazio)'
            }
          }
        },

        // ─── Autor Schemas ───────────────────────────────────────────────
        Autor: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            nome: { type: 'string', example: 'Machado de Assis' }
          }
        },
        AutorInput: {
          type: 'object',
          required: ['nome'],
          properties: {
            nome: {
              type: 'string',
              example: 'Guimarães Rosa',
              description: 'Nome completo do autor (obrigatório)'
            }
          }
        },

        // ─── Error Schemas ───────────────────────────────────────────────
        Erro400: {
          type: 'object',
          properties: {
            erro: { type: 'string', example: 'Campos obrigatórios não informados.' }
          }
        },
        Erro401: {
          type: 'object',
          properties: {
            erro: { type: 'string', example: 'Token não fornecido. Acesso negado.' }
          }
        },
        Erro403: {
          type: 'object',
          properties: {
            erro: { type: 'string', example: 'Acesso negado: permissão insuficiente.' }
          }
        },
        Erro404: {
          type: 'object',
          properties: {
            erro: { type: 'string', example: 'Recurso não encontrado.' }
          }
        },
        Erro409: {
          type: 'object',
          properties: {
            erro: { type: 'string', example: 'E-mail já cadastrado.' }
          }
        },
        Erro422: {
          type: 'object',
          properties: {
            erro: { type: 'string', example: 'Dados inválidos ou incompletos.' }
          }
        },
        Erro500: {
          type: 'object',
          properties: {
            erro: { type: 'string', example: 'Erro interno do servidor.' }
          }
        }
      }
    },
    tags: [
      {
        name: 'Autenticação',
        description: 'Rotas públicas para registro e login de usuários'
      },
      {
        name: 'Livros',
        description: 'Gerenciamento do catálogo de livros'
      },
      {
        name: 'Autores',
        description: 'Gerenciamento de autores (criação restrita a ADMIN)'
      }
    ]
  },
  apis: ['./routes/*.js']
};

const swaggerSpec = swaggerJsdoc(options);

module.exports = swaggerSpec;
