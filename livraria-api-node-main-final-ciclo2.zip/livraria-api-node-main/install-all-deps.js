/**
 * Instalador recursivo de dependências npm usando agy-node
 * Execute: agy-node install-all-deps.js
 */
const https = require('https');
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const PACKAGES_DIR = path.join(__dirname, 'node_modules');
const EXTRACT_SCRIPT = path.join(__dirname, 'extract-pkg.js');
const NODE_EXE = process.execPath;

const installed = new Set();
const queue = [];

// Fila inicial de pacotes a instalar
const initialPackages = [
  '@apidevtools/swagger-parser',
  'commander',
  'doctrine',
  'glob',
  'lodash.mergewith',
  'yaml',
  'swagger-ui-dist'
];

function downloadFile(url, destPath) {
  return new Promise((resolve, reject) => {
    function doRequest(currentUrl) {
      https.get(currentUrl, (res) => {
        if ([301, 302, 307, 308].includes(res.statusCode)) {
          doRequest(res.headers.location);
          return;
        }
        if (res.statusCode !== 200) {
          reject(new Error('HTTP ' + res.statusCode + ' for ' + currentUrl));
          return;
        }
        const file = fs.createWriteStream(destPath);
        res.pipe(file);
        file.on('finish', () => { file.close(); resolve(); });
        file.on('error', reject);
        res.on('error', reject);
      }).on('error', reject);
    }
    doRequest(url);
  });
}

function getPackageInfo(pkgName) {
  return new Promise((resolve, reject) => {
    const encoded = pkgName.replace('@', '%40').replace('/', '%2F');
    const registryUrl = 'https://registry.npmjs.org/' + encoded + '/latest';
    https.get(registryUrl, (res) => {
      if ([301, 302, 307, 308].includes(res.statusCode)) {
        // Follow redirect for registry too
        https.get(res.headers.location, (res2) => {
          let data = '';
          res2.on('data', (chunk) => { data += chunk; });
          res2.on('end', () => {
            try { resolve(JSON.parse(data)); }
            catch (e) { reject(e); }
          });
          res2.on('error', reject);
        }).on('error', reject);
        return;
      }
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error('Parse error for ' + pkgName + ': ' + e.message)); }
      });
      res.on('error', reject);
    }).on('error', reject);
  });
}

function isInstalled(pkgName) {
  return fs.existsSync(path.join(PACKAGES_DIR, pkgName));
}

async function installPackage(pkgName) {
  if (installed.has(pkgName) || isInstalled(pkgName)) {
    return;
  }
  installed.add(pkgName);

  console.log('[INSTALANDO] ' + pkgName);

  let info;
  try {
    info = await getPackageInfo(pkgName);
  } catch (e) {
    console.error('  [ERRO] Nao foi possivel obter info de ' + pkgName + ': ' + e.message);
    return;
  }

  const tarball = info.dist.tarball;
  const safeName = pkgName.replace('@', '').replace('/', '_');
  const tmpTgz = path.join(PACKAGES_DIR, '_tmp_' + safeName + '.tgz');

  try {
    await downloadFile(tarball, tmpTgz);
  } catch (e) {
    console.error('  [ERRO] Download falhou para ' + pkgName + ': ' + e.message);
    if (fs.existsSync(tmpTgz)) fs.unlinkSync(tmpTgz);
    return;
  }

  try {
    // Para pacotes com escopo (@org/pkg), precisamos criar o diretório @org primeiro
    const pkgDir = path.join(PACKAGES_DIR, pkgName);
    const pkgParentDir = path.dirname(pkgDir);
    if (!fs.existsSync(pkgParentDir)) fs.mkdirSync(pkgParentDir, { recursive: true });

    execFileSync(NODE_EXE, [EXTRACT_SCRIPT, tmpTgz, pkgParentDir, path.basename(pkgName)], {
      stdio: 'pipe'
    });
  } catch (e) {
    console.error('  [ERRO] Extracao falhou para ' + pkgName + ': ' + e.message);
    if (fs.existsSync(tmpTgz)) fs.unlinkSync(tmpTgz);
    return;
  }

  if (fs.existsSync(tmpTgz)) fs.unlinkSync(tmpTgz);
  console.log('  [OK] ' + pkgName + '@' + info.version);

  // Instala dependências transitivas
  const deps = info.dependencies || {};
  for (const dep of Object.keys(deps)) {
    if (!installed.has(dep) && !isInstalled(dep)) {
      queue.push(dep);
    }
  }
}

async function main() {
  console.log('Instalando dependencias transitivas...');
  console.log('=======================================\n');

  for (const pkg of initialPackages) {
    queue.push(pkg);
  }

  while (queue.length > 0) {
    const pkg = queue.shift();
    if (!installed.has(pkg) && !isInstalled(pkg)) {
      await installPackage(pkg);
    }
  }

  console.log('\n[OK] Todas as dependencias instaladas!');

  // Verifica o servidor
  console.log('\nVerificando se o servidor carrega...');
  try {
    execFileSync(NODE_EXE, ['-e', 'require(\'./swagger\'); console.log(\'swagger.js OK\');'], {
      cwd: __dirname,
      stdio: 'inherit'
    });
  } catch (e) {
    console.error('[ERRO]', e.message);
  }
}

main().catch((err) => {
  console.error('[ERRO FATAL]', err.message);
  process.exit(1);
});
