const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const repository = require('../repositories/LivrariaRepository');

const JWT_SECRET = process.env.JWT_SECRET || 'secreto_livraria_jwt';

class AuthService {
  async register({ nome, email, senha, role = 'USER' } = {}) {
    if (!nome || !email || !senha) {
      const erro = new Error('Nome, email e senha são obrigatórios.');
      erro.status = 422;
      throw erro;
    }

    if (typeof email !== 'string' || !email.includes('@')) {
      const erro = new Error('Formato de email inválido.');
      erro.status = 422;
      throw erro;
    }

    if (typeof senha !== 'string' || senha.length < 6) {
      const erro = new Error('A senha deve possuir no mínimo 6 caracteres.');
      erro.status = 422;
      throw erro;
    }

    const usuarioExistente = repository.buscarUsuarioPorEmail(email);
    if (usuarioExistente) {
      const erro = new Error('E-mail já cadastrado.');
      erro.status = 409;
      throw erro;
    }

    if (!['USER', 'ADMIN'].includes(String(role).toUpperCase())) {
      const erro = new Error('Perfil deve ser USER ou ADMIN.');
      erro.status = 422;
      throw erro;
    }

    const salt = await bcrypt.genSalt(10);
    const senhaHash = await bcrypt.hash(senha, salt);

    const novoUsuario = repository.cadastrarUsuario({
      nome,
      email,
      senhaHash,
      role: role.toUpperCase()
    });

    const { senhaHash: _, ...usuarioSemSenha } = novoUsuario;
    return usuarioSemSenha;
  }

  async login({ email, senha } = {}) {
    if (!email || !senha) {
      const erro = new Error('Email e senha são obrigatórios.');
      erro.status = 400;
      throw erro;
    }

    const usuario = repository.buscarUsuarioPorEmail(email);
    if (!usuario) {
      const erro = new Error('Credenciais inválidas.');
      erro.status = 401;
      throw erro;
    }

    const senhaValida = await bcrypt.compare(senha, usuario.senhaHash);
    if (!senhaValida) {
      const erro = new Error('Credenciais inválidas.');
      erro.status = 401;
      throw erro;
    }

    const token = jwt.sign(
      { id: usuario.id, email: usuario.email, role: usuario.role },
      JWT_SECRET,
      { expiresIn: '8h' }
    );

    return {
      token,
      usuario: {
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email,
        role: usuario.role
      }
    };
  }
}

module.exports = new AuthService();