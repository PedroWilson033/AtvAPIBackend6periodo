/**
 * Script de instalação de pacotes usando agy-node (Node.js via Antigravity/Electron)
 * Execute: agy-node install-swagger.js
 */
const https = require('https');
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const PACKAGES_DIR = path.join(__dirname, 'node_modules');
const EXTRACT_SCRIPT = path.join(__dirname, 'extract-pkg.js');
const NODE_EXE = process.execPath;

/**
 * Faz download de um arquivo via HTTPS, seguindo redirecionamentos
 */
function downloadFile(url, destPath) {
  return new Promise((resolve, reject) => {
    function doRequest(currentUrl) {
      https.get(currentUrl, (res) => {
        if ([301, 302, 307, 308].includes(res.statusCode)) {
          doRequest(res.headers.location);
          return;
        }
        const file = fs.createWriteStream(destPath);
        res.pipe(file);
        file.on('finish', () => { file.close(); resolve(); });
        file.on('error', reject);
        res.on('error', reject);
      }).on('error', reject);
    }
    doRequest(url);
  });
}

/**
 * Lê o JSON do npm registry para um pacote
 */
function getPackageInfo(pkgName) {
  return new Promise((resolve, reject) => {
    const encoded = pkgName.replace('/', '%2F');
    https.get('https://registry.npmjs.org/' + encoded + '/latest', (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(e); }
      });
      res.on('error', reject);
    }).on('error', reject);
  });
}

async function installPackage(pkgName) {
  console.log('\n[INSTALANDO] ' + pkgName + '...');
  
  const pkgDestDir = path.join(PACKAGES_DIR, pkgName);
  if (fs.existsSync(pkgDestDir)) {
    console.log('  [OK] ' + pkgName + ' ja esta instalado.');
    return;
  }

  const info = await getPackageInfo(pkgName);
  const tarball = info.dist.tarball;
  console.log('  [DOWNLOAD] ' + pkgName + '@' + info.version);
  
  const tmpTgz = path.join(PACKAGES_DIR, '_tmp_' + pkgName.replace('/', '_') + '.tgz');
  await downloadFile(tarball, tmpTgz);
  console.log('  [DOWNLOAD] Concluido.');
  
  console.log('  [EXTRACT] Extraindo...');
  execFileSync(NODE_EXE, [EXTRACT_SCRIPT, tmpTgz, PACKAGES_DIR, pkgName], {
    stdio: 'inherit'
  });
  
  if (fs.existsSync(tmpTgz)) fs.unlinkSync(tmpTgz);
  console.log('  [OK] ' + pkgName + '@' + info.version + ' instalado!');
}

async function main() {
  console.log('Instalador de Swagger para Livraria API');
  console.log('=======================================\n');
  
  const packages = ['swagger-jsdoc', 'swagger-ui-express'];
  
  for (const pkg of packages) {
    await installPackage(pkg);
  }
  
  console.log('\n[OK] Instalacao concluida! Inicie o servidor com:');
  console.log('   agy-node server.js');
}

main().catch((err) => {
  console.error('[ERRO]', err.message);
  process.exit(1);
});
