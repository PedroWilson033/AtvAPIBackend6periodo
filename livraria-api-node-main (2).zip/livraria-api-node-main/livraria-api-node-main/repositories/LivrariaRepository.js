const bcrypt = require('bcryptjs');

class LivrariaRepository {
  constructor() {
    this.autores = [
      { id: 1, nome: "Machado de Assis" },
      { id: 2, nome: "Clarice Lispector" }
    ];

    this.livros = [
      { id: 1, titulo: "Dom Casmurro", ano: 1899, autor_id: 1, comentarios: [] },
      { id: 2, titulo: "Quincas Borba", ano: 1891, autor_id: 1, comentarios: [] }
    ];

    // Usuários com senhas criptografadas por BCrypt
    this.usuarios = [
      {
        id: 1,
        nome: "Admin",
        email: "admin@livraria.com",
        senhaHash: bcrypt.hashSync('admin123', 10), // admin123
        role: "ADMIN"
      },
      {
        id: 2,
        nome: "Leitor",
        email: "leitor@gmail.com",
        senhaHash: bcrypt.hashSync('leitor123', 10), // leitor123
        role: "USER"
      }
    ];
  }

  // Métodos de Autores
  listarAutores() { return this.autores; }
  buscarAutorPorId(id) { return this.autores.find(a => a.id === Number(id)); }
  cadastrarAutor(autor) {
    const novoAutor = { id: this.autores.length + 1, ...autor };
    this.autores.push(novoAutor);
    return novoAutor;
  }

  // Métodos de Livros
  listarLivros() {
    return this.livros.map(livro => {
      const autor = this.buscarAutorPorId(livro.autor_id);
      return {
        ...livro,
        autor_nome: autor ? autor.nome : "Desconhecido",
        comentarios: livro.comentarios || []
      };
    });
  }
  buscarLivroPorId(id) {
    const livro = this.livros.find(l => l.id === Number(id));
    if (!livro) return null;
    const autor = this.buscarAutorPorId(livro.autor_id);
    return { ...livro, autor_nome: autor ? autor.nome : "Desconhecido" };
  }
  cadastrarLivro(livro) {
    const novoLivro = { id: this.livros.length + 1, comentarios: [], ...livro };
    this.livros.push(novoLivro);
    return novoLivro;
  }
  adicionarComentario(livroId, comentario) {
    const livro = this.livros.find(l => l.id === Number(livroId));
    if (livro) {
      livro.comentarios.push(comentario);
      return true;
    }
    return false;
  }

  // Métodos de Usuários
  buscarUsuarioPorEmail(email) {
    return this.usuarios.find(u => u.email === email);
  }
  cadastrarUsuario(usuario) {
    const novoUsuario = { id: this.usuarios.length + 1, ...usuario };
    this.usuarios.push(novoUsuario);
    return novoUsuario;
  }
}

module.exports = new LivrariaRepository();