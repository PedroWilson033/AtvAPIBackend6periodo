const LivroService = require('../services/LivroService');

class LivroController {
  listar(req, res, next) {
    try {
      const livros = LivroService.listar();
      return res.status(200).json(livros);
    } catch (error) {
      next(error);
    }
  }

  buscarPorId(req, res, next) {
    try {
      const livro = LivroService.buscarPorId(req.params.id);
      return res.status(200).json(livro);
    } catch (error) {
      next(error);
    }
  }

  cadastrar(req, res, next) {
    try {
      const novoLivro = LivroService.cadastrar(req.body);
      return res.status(201).json(novoLivro);
    } catch (error) {
      next(error);
    }
  }

  adicionarComentario(req, res, next) {
    try {
      const { texto } = req.body;
      const autor_comentario = req.usuario ? req.usuario.email : "Anônimo";
      const resultado = LivroService.adicionarComentario(req.params.id, { texto, autor_comentario });
      return res.status(201).json(resultado);
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new LivroController();