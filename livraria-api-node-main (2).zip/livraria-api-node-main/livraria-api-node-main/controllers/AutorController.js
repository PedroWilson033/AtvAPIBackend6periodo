const autorService = require('../services/AutorService');

class AutorController {
  listar(req, res, next) {
    try {
      return res.status(200).json(autorService.listar());
    } catch (error) {
      next(error);
    }
  }

  buscarPorId(req, res, next) {
    try {
      const autor = autorService.buscarPorId(req.params.id);
      if (!autor) return res.status(404).json({ erro: 'Autor não encontrado.' });
      return res.status(200).json(autor);
    } catch (error) {
      next(error);
    }
  }

  cadastrar(req, res, next) {
    try {
      const novoAutor = autorService.cadastrar(req.body);
      return res.status(201).json(novoAutor);
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new AutorController();