const repository = require('../repositories/LivrariaRepository');

class LivroService {
  // Ajustado de listarTodos para listar
  listar() {
    const livros = repository.listarLivros();
    const autores = repository.listarAutores();

    return livros.map(livro => {
      const autor = autores.find(a => a.id === livro.autor_id);
      return {
        ...livro,
        autor_nome: autor ? autor.nome : "Autor Desconhecido",
        comentarios: livro.comentarios || [] // Garante o array de comentários
      };
    });
  }

  buscarPorId(id) {
    const livro = repository.buscarLivroPorId(id);
    if (!livro) {
      throw { status: 404, message: "Livro não localizado." };
    }

    const autor = repository.buscarAutorPorId(livro.autor_id);
    return {
      ...livro,
      autor_nome: autor ? autor.nome : "Autor Desconhecido",
      comentarios: livro.comentarios || []
    };
  }

  cadastrar({ titulo, ano, autor_id }) {
    if (!titulo || !autor_id) {
      throw { status: 400, message: "O título e o autor_id são obrigatórios." };
    }

    const autor = repository.buscarAutorPorId(autor_id);
    if (!autor) {
      throw { status: 404, message: "O autor informado não existe." };
    }

    return repository.cadastrarLivro({
      titulo: titulo.trim(),
      ano: Number(ano) || new Date().getFullYear(),
      autor_id: Number(autor_id)
    });
  }

  adicionarComentario(livroId, { texto, autor_comentario }) {
    if (!texto || texto.trim() === "") {
      throw { status: 400, message: "O texto do comentário não pode estar vazio." };
    }

    this.buscarPorId(livroId);

    // Salva usando autor_comentario para compatibilidade com o index.html
    return repository.adicionarComentario(livroId, {
      autor_comentario: autor_comentario || "Anônimo",
      texto: texto.trim()
    });
  }
}

module.exports = new LivroService();