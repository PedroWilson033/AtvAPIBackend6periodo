const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const repository = require('../repositories/LivrariaRepository');

const JWT_SECRET = process.env.JWT_SECRET || 'secreto_livraria_jwt';

class AuthService {
  async register({ nome, email, senha, role = 'USER' }) {
    const usuarioExistente = repository.buscarUsuarioPorEmail(email);
    if (usuarioExistente) {
      const erro = new Error('E-mail já cadastrado.');
      erro.status = 400;
      throw erro;
    }

    const salt = await bcrypt.genSalt(10);
    const senhaHash = await bcrypt.hash(senha, salt);

    const novoUsuario = repository.cadastrarUsuario({
      nome,
      email,
      senhaHash,
      role: role.toUpperCase()
    });

    const { senhaHash: _, ...usuarioSemSenha } = novoUsuario;
    return usuarioSemSenha;
  }

  async login({ email, senha }) {
    const usuario = repository.buscarUsuarioPorEmail(email);
    if (!usuario) {
      const erro = new Error('Credenciais inválidas.');
      erro.status = 401;
      throw erro;
    }

    const senhaValida = await bcrypt.compare(senha, usuario.senhaHash);
    if (!senhaValida) {
      const erro = new Error('Credenciais inválidas.');
      erro.status = 401;
      throw erro;
    }

    const token = jwt.sign(
      { id: usuario.id, email: usuario.email, role: usuario.role },
      JWT_SECRET,
      { expiresIn: '8h' }
    );

    return {
      token,
      usuario: {
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email,
        role: usuario.role
      }
    };
  }
}

module.exports = new AuthService();