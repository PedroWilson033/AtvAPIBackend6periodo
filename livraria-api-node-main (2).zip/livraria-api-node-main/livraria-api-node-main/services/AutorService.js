const repository = require('../repositories/LivrariaRepository');

class AutorService {
  listar() {
    return repository.listarAutores();
  }

  buscarPorId(id) {
    return repository.buscarAutorPorId(id);
  }

  cadastrar(dados) {
    if (!dados.nome) {
      const erro = new Error('Nome do autor é obrigatório.');
      erro.status = 400;
      throw erro;
    }
    return repository.cadastrarAutor(dados);
  }
}

module.exports = new AutorService();