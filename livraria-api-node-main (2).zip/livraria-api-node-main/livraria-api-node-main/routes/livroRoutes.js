const express = require('express');
const router = express.Router();
const LivroController = require('../controllers/LivroController');
const { autenticarToken, autorizarRoles } = require('../middlewares/authMiddleware');

router.get('/', LivroController.listar);
router.get('/:id', LivroController.buscarPorId);

// Exclusivo ADMIN
router.post('/', autenticarToken, autorizarRoles('ADMIN'), LivroController.cadastrar);

// Usuários Autenticados (USER ou ADMIN)
router.post('/:id/comentarios', autenticarToken, autorizarRoles('USER', 'ADMIN'), LivroController.adicionarComentario);

module.exports = router;