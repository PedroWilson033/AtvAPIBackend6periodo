const express = require('express');
const router = express.Router();
const AutorController = require('../controllers/AutorController');
const { autenticarToken, autorizarRoles } = require('../middlewares/authMiddleware');

router.get('/', AutorController.listar);
router.get('/:id', AutorController.buscarPorId);
router.post('/', autenticarToken, autorizarRoles('ADMIN'), AutorController.cadastrar);

module.exports = router;